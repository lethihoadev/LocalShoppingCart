import React, { Component } from 'react';
import './App.css';
import AddProduct from './components/AddProduct.js';
import Products from './components/Products';
import Cart from './components/Cart';

class App extends Component {
  constructor(){
    super();
    this.state = {
      menu:"products"
    }
    this.onAddProductClicked=this.onAddProductClicked.bind(this);
    this.onProductClicked=this.onProductClicked.bind(this);
    this.onAddCartClicked=this.onAddCartClicked.bind(this);
  }
  onProductClicked(){
    this.setState({
      menu:"products"
    })
  }
  onAddProductClicked(){
    this.setState({
      menu:"add-product"
    })
  }
  onAddCartClicked(){
    this.setState({
      menu:"cart-product"
    })
  }
  render(){
    return (
      <div className="App">
        <div className="menu">
          <button onClick={this.onProductClicked}>Products</button>
          <button onClick={this.onAddProductClicked}>Add Product</button>
          <button onClick={this.onAddCartClicked}>Cart</button>
        </div>
        {this.state.menu == "products" ?<Products/>:null}
        {this.state.menu == "add-product" ? <AddProduct/>:null}
        {this.state.menu == "cart-product" ? <Cart/>:null}
      </div>
    );

  }
}

export default App;
