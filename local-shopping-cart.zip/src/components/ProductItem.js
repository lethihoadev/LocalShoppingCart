import React, { Component } from 'react';
import '../components/AddProduct.css';

class ProductItem extends Component {
    
render(){
    const {onItemClick} = this.props;
    return(
        <div className="cont">
            <div className="pro">
                <h5>{this.props.item.title}</h5>
                <h5>{this.props.item.price}</h5>
                <button className="btn1" onClick={onItemClick}>Add</button>
            </div>
        </div>
    );
}
}

export default ProductItem;