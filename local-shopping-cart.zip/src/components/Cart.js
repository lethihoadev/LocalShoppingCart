import React, { Component } from 'react';
import CartItem from './CartItem';

class Cart extends Component {
    constructor() {
        super();
        this.state = {
            cart: JSON.parse(localStorage.getItem("cart"))
        }
        if (!this.state.cart) {
            this.state.cart = [];
        }
    }
    onDelete(item) {
        return (event) => {
            let cart = JSON.parse(localStorage.getItem("cart"));
            let oldItem = cart.find((element) => element.id == item.id);
            cart.splice(cart.indexOf(oldItem), 1);
            localStorage.setItem("cart", JSON.stringify(cart));
            console.log(cart);
            window.location.reload();
        }
    }
    sumMoney() {
        var totalProduct = 0;
        for (var i = 0; i <  this.state.cart.length; i++) {
            totalProduct +=  this.state.cart[i].price *  this.state.cart[i].quantity;
        }
        return totalProduct;
    }
    render() {
        return (
            <div>
                <div>{this.state.cart.length} item(s)</div>
                <div>{this.sumMoney()} $</div>
                {this.state.cart.map((item, index) =>
                    <CartItem onDelete={this.onDelete(item)} item={item} />
                )}
            </div>
        );
    }
}
export default Cart;