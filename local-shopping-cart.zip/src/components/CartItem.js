import React, { Component } from 'react';

class CartItem extends Component {
    render(){
        const {onDelete} = this.props;
        return(
            <div className="cont">
            <div className="pro">
                <h5>{this.props.item.title}</h5>
                <h5>Price: {this.props.item.price}</h5>
                <h5>Quantity: {this.props.item.quantity}</h5>
                <button className="btn2" onClick={onDelete}>Delete</button>
            </div>
        </div>
        );
    }
}
export default CartItem;