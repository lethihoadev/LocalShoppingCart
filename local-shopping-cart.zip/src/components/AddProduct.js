import React, { Component } from 'react';
import '../components/AddProduct.css';

class AddProduct extends Component{

    onAddProduct(event){
        event.preventDefault();
		let title = event.target["title"].value;
        let price = event.target["price"].value;
        let products = JSON.parse(localStorage.getItem("products"));
        if(!products){
            products = [];
        }
        
        let product = {
            id:products.length+1,
            title:title,
            price:price
        }
        products.push(product);
        localStorage.setItem("products",JSON.stringify(products));
        console.log(products);
    }

    render(){
        return (
            <div className="conent">
            <form className="AddProduct" onSubmit={this.onAddProduct}>
                <h3>Add Product</h3>
                <input type="text" name="title"/>
                <input type="text" name="price"/>
                <button className="btn">Add</button>
            </form>
            </div>
          );
    }

}

export default AddProduct;